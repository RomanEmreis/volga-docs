# Routing and extractors

## Mapping routes

`App` and `RouteGroup` share the same mapping surface.

<!-- snippet: skip -->
```rust
app.map_get("/items", list);
app.map_post("/items", create);
app.map_put("/items/{id}", replace);
app.map_patch("/items/{id}", update);
app.map_delete("/items/{id}", remove);
app.map_head("/items/{id}", head);
app.map_options("/items", options);
app.map_query("/search", search);     // the HTTP QUERY verb (0.9.4+)
app.map_trace("/", trace);
app.map_connect("/", connect);

// any verb, including ones without a helper
app.map("PURGE", "/cache/{key}", purge);
```

`map_get` also answers `HEAD` for the same path — headers, no body. Since
0.10.0 there is no second route behind that: routing hands a `HEAD` request
with no route of its own to the `GET` route, so it travels through that
route's middleware, group middleware and CORS policy. A `HEAD` health check
against a route behind `authorize` now answers `401` / `403` where it used
to answer `200`. `App::without_implicit_head()` is **removed**; map
`map_head` explicitly to override the path, which takes precedence and runs
its own middleware and none of the `GET` route's.

Two routes reaching one position under **different parameter names** panic
at registration in two cases — one verb naming its own route twice
(`map_get("/users/{id}")` then `map_get("/users/{name}")`), and a `GET` and
a `HEAD` disagreeing. Any other verb may name the position whatever it
likes. See "Path parameters" below.

Mapping a route that is already mapped **replaces** it, along with the
middleware bound to the registration being replaced. `/x`, `/x/` and `//x`
are one route everywhere it is remembered.

Unmatched paths go to the fallback:

```rust
app.map_fallback(|| async { not_found!("no such route") });
```

A fallback takes anything implementing `FromRequestParts` — headers, the
URI, cookies, `ClientIp`, `Dc<T>`, `HostEnv`, `Config<T>` — but not the
body and not path parameters. Since 0.10.0 the per-request scope is built
for these requests, so those extractors work rather than failing with a
`500`, and an error out of a fallback is answered by the application's
`map_err`. `FromRawRequest` is removed; `FallbackHandler::call` now takes
an `HttpRequest`.

Since 0.11.1 a **group** carries a fallback of its own, for the requests
under its prefix that no route answers — any method:

```rust
use volga::{http::Uri, not_found, ok};

app.group("/api", |api| {
    api.map_get("/models", || async { ok!("models") });

    // GET /api/nope, POST /api/v1/x, DELETE /api -> here
    // POST /api/models                           -> 405, a route is there
    api.map_fallback(|uri: Uri| async move {
        not_found!("no endpoint at {}", uri.path())
    });
});
```

The router resolves it as it resolves routes: the **deepest prefix wins**
(`/api/v2` before `/api`, and either before a `/{*path}` route or a static
shell under `/`), a route answers first for its own method and `405` for
one it lacks, and the group's middleware and CORS policy wrap it. Unlike
`App::map_fallback` it **does** bind path parameters — the ones its prefix
declares, read with `NamedPath<T>`, the same at the prefix and below it;
under a prefix ending in `{*name}` it answers everything that catch-all
reads. It is not a route: not listed, not in OpenAPI, and
`ctx.matched_route()` is `false` for it, so a preflight for a path only it
answers is not treated as an endpoint's. A second fallback at one prefix
replaces the first.

Reach for it whenever an API shares a server with an SPA shell: the shell
turns every unknown path into HTML `200`, which is wrong for `/api/uesrs`,
and a group fallback gives that subtree the JSON `404` its clients parse.

## Route groups

<!-- snippet: skip -->
```rust
app.group("/api/v1", |api| {
    api.map_get("/users", list_users);         // GET /api/v1/users
    api.map_post("/users", create_user);
    api.map_get("/users/{id}", get_user);
});
```

A group is the unit that middleware, CORS policies, rate-limit policies,
request body limits (0.13.1+) and authorization attach to — anything callable on a `Route` is callable on the
group, and applies to every route inside it.

Since 0.10.0 a group is a real **scope**: it applies what it holds once its
closure returns, so a `g.with(require_api_key)` written *below* a route
reaches that route too. Before 0.10.0 the group read its configuration at
each `map_*`, and anything registered after a route silently missed it —
which is how routes ended up escaping their group's `authorize` or
`token_bucket`. Middleware still *runs* in registration order, an outer
scope wraps an inner one, and a CORS policy or body limit chosen by a
route or a nested group is not replaced by the enclosing group's.

## Handlers

A handler is a function or closure whose parameters are extractors and whose
result implements `IntoResponse`. Since 0.11.0 it comes in two shapes, told
apart by the signature: **asynchronous** (`async fn`, or a closure returning
a future) and **synchronous** (a plain `fn`, or a closure returning the
response itself). All of these are handlers:

<!-- snippet: skip -->
```rust
app.map_get("/sum/{x}/{y}", |x: i32, y: i32| async move { x + y });

async fn get_user(id: u64, repo: Dc<Repo>) -> HttpResult {
    match repo.find(id).await? {
        Some(user) => ok!(user),
        None => not_found!("user not found"),
    }
}
app.map_get("/users/{id}", get_user);

// synchronous: nothing to await, so no future to build (0.11.0+)
app.map_get("/sum/{x}/{y}", |x: i32, y: i32| x + y);
app.map_get("/hello/{name}", |name: String| ok!("Hello {name}!"));
```

Use the synchronous shape for work with nothing to await — formatting,
arithmetic, an in-memory lookup, a header check. Extraction is identical:
`Json<T>`, `Form<T>`, `Query<T>` and `Dc<T>` arrive with the body already
read, and OpenAPI describes the route the same way. It runs inline on the
runtime worker polling the request, like an `async` body with no `.await`,
and costs the same.

A synchronous body that **blocks** — `std::fs`, a synchronous DB driver, a
long computation — goes in `volga::blocking`, which runs it on Tokio's
blocking pool while the extractors still run on the worker:

```rust
use volga::{blocking, HttpResult};

app.map_get("/reports/{id}", blocking(|id: u32| -> HttpResult {
    let report = std::fs::read_to_string(format!("reports/{id}.txt"))?;
    ok!(report)
}));
```

`blocking` takes only a synchronous handler (an `async` one is a compile
error), shares it across requests instead of cloning it (captures need not
be `Clone`), and resumes a panic on the awaiting task. The offloaded call is
**not** cancelled with the request — a long body checks a
`CancellationToken` itself. Never put blocking work in a plain synchronous
handler: it stalls every other request that worker would have polled.

Both shapes are accepted by every `map_*` and `map` on `App` and
`RouteGroup`, `map_fallback`, `map_err`, `map_conn` and `map_msg`.

The shape is carried by a marker (`volga::marker::{Async, Immediate}`),
the **last** generic parameter of every registering method and handler
trait, defaulted to `Async`. It is inferred, so only a call site that spells
generics out changes: `app.map_get::<_, _, (i32,), _>(..)`. A bound
`F: GenericHandler<Args>` still means the async shape; add a generic `M`
(`F: GenericHandler<Args, M>`) to accept both. `App::map` / `RouteGroup::map`
call their method parameter `V`, and `map_msg` / `MessageHandler` call the
message type `Msg`.

Returning `HttpResult` is the normal choice: it lets `?` propagate failures
into the error pipeline. Bare `i32`, `String`, `&'static str`, `Vec<u8>`,
`Json<T>`, `Form<T>`, `Multipart` and `std::io::Error` all implement
`IntoResponse` too — convenient for small handlers, but they cannot use `?`.

## Path parameters

Three mutually exclusive styles. **Never mix them in one handler** — the
`Path` / `NamedPath` extractors read a snapshot and the positional
parameters consume the same arguments.

```rust
// 1. positional — declared in the order they appear in the pattern
app.map_get("/hello/{descr}/{name}", |descr: String, name: String| async move {
    ok!("Hello {} {}!", descr, name)
});

// 2. positional tuple — or, on a route declaring exactly one parameter, a single type
use volga::Path;
app.map_get("/hello/{name}/{age}", |Path((name, age)): Path<(String, u32)>| async move {
    ok!("Hello {name}, age {age}")
});
app.map_get("/users/{id}", |Path(id): Path<u64>| ok!("user {id}")); // 0.13.0+

// 3. named struct — needs serde::Deserialize
use volga::NamedPath;
use serde::Deserialize;

#[derive(Deserialize)]
struct Params { name: String, age: u32 }

app.map_get("/hello/{name}/{age}", |NamedPath(p): NamedPath<Params>| async move {
    ok!("Hello {}, age {}", p.name, p.age)
});
```

A positional parameter is any type implementing `FromPathArg`: the
primitives, `String`, `Box<str>`, `Cow<'static, str>`, the `std::net`
addresses, `PathBuf` and, with the `uuid` feature (in `full`, 0.13.0+),
`uuid::Uuid`. A value that fails to parse answers `400` before the handler
runs.

* **`Path<T>` of a single type reads exactly one parameter** (0.13.0+). On a
  route declaring two, `Path<u32>` answers `500` rather than take the first —
  `Path<OrderId>` on `/users/{user_id}/orders/{order_id}` would read the
  user's id. Use a tuple or `NamedPath<T>` there.
* A handler reading more positional parameters than its route declares
  answers `500`; an extra `Option<T>` reads `None`.
* `Path<SomeStruct>` does not compile — a struct goes into `NamedPath<T>`,
  and the error says so.

### Path parameters of your own types (0.13.0+)

`volga::http::endpoints::args::{FromPathArg, PathArg}` are public. Implement
`FromPathArg` and the type is a handler argument, a `Path<(..)>` element and
the `T` of `Path<T>`. `PathArg::parse` goes through `FromStr` and answers
`400` on failure, so a newtype takes one line:

```rust
use volga::{Path, error::Error, ok};
use volga::http::endpoints::args::{FromPathArg, PathArg};

struct OrderId(u64);

impl FromPathArg for OrderId {
    fn from_path_arg(arg: &PathArg) -> Result<Self, Error> {
        arg.parse().map(OrderId)
    }
}

app.map_get("/orders/{id}", |id: OrderId| ok!("order {}", id.0));
app.map_get(
    "/users/{user_id}/orders/{order_id}",
    |Path((user, order)): Path<(u64, OrderId)>| ok!("order {} of user {user}", order.0),
);
```

`PathArg::name()` is the name the pattern gives it, `value()` the decoded
value; a hand-written check returns any error, e.g.
`Error::client_error(format!("{} is not a valid slug", arg.name()))` (a `400`).
Don't put rules in `FromPathArg` that belong in `Validate` — a single
parameter validates as `Valid<Path<T>>` (see `references/validation.md`).

`FromPathArgs` (what `Path<T>` reads its `T` through) is implementable too:
`PathArgs::iter()` yields the parameters in pattern order, with `len()` /
`is_empty()`. Answer `500` when the route does not declare what the type
reads — that is a code mistake, not a bad request. A `FromPathArgs` type is
read **only** through `Path<T>` (`|Path(range): Path<Range>|`); unlike a
`FromPathArg` type it is not a handler argument of its own, and
`|range: Range|` fails with "not an extractor".

`uuid::Uuid` needs the `uuid` feature **and** the `uuid` crate as a
dependency for the type name — volga does not re-export it:

```rust
use uuid::Uuid;

app.map_get("/files/{id}", |id: Uuid| ok!("file {id}")); // not a UUID -> 400
```

Since 0.10.0 each endpoint binds the names **its own pattern** was written
with, so `POST /users/{name}` mapped beside `GET /users/{id}` binds `name`.
Before 0.10.0 the whole position took whichever name reached it first, so
`NamedPath<T>` on the `POST` was handed `id` and failed to deserialize —
and a handler written around that, reading `id` from a route that says
`{name}`, now reads nothing. Positional extractors never looked at the name
and are unaffected.

A literal segment wins over a parameter wherever both could match, but only
where it leads to a route: since 0.10.1 a lookup that runs out of literals
backtracks to the nearest parameter it passed over. `GET /files/{name}`
answers `/files/shared` even with `/files/shared/latest` mapped beside it —
before 0.10.1 mapping the longer route made the shorter request `404`. A
literal carrying a handler for another method still answers `405` rather
than falling through to a parameter, and each node is visited at most once.

### Catch-all parameters (0.11.0+)

A route's **last** segment can be `{*name}`, binding the rest of the path as
one value:

```rust
// GET /files/docs/2026/report.pdf -> path = "docs/2026/report.pdf"
app.map_get("/files/{*path}", |path: String| async move { ok!("{path}") });
```

* It reads **at least one** segment: `/files` and `/files/` are not
  answered by it and can be mapped separately.
* The value is the rest of the path, separators and a trailing `/` kept,
  decoded whole (0.13.0): `GET /files/a%2Fb/c` binds `"a/b/c"`.
* Precedence at every position: literal, then parameter, then catch-all;
  the first position two routes differ at decides, in any mapping order.
  `/assets/{*path}` answers `/assets/app.js` ahead of `/{lang}/{page}`.
* A segment after a catch-all — including a route inside a group whose
  prefix ends in one — **panics** at mapping. One verb naming the catch-all
  differently twice panics like any parameter.
* **Nothing is normalized**: `GET /files/../../etc/passwd` binds
  `"../../etc/passwd"`. A handler joining the value onto a directory must
  reject `..`, roots and drive prefixes, or canonicalize and check the
  prefix. For serving files use `use_static_files()`, which does this.
* OpenAPI describes it as the path parameter `{name}`. Beside a parameter
  route of the same verb at the same position (`/files/{name}` and
  `/files/{*path}`) the catch-all is left out of the shared document, with a
  debug-build warning at startup.

### How values are decoded (0.13.0+)

The router percent-decodes the path **once**, segment by segment, and every
extractor — plain arguments, `FromPathArg` types, `Path<T>`, `NamedPath<T>` —
reads the decoded value: `John%20Doe` → `"John Doe"`, `100%25` → `"100%"`,
`%31` into a `u32` → `1`. `+` and `&` are literal path characters:
`/files/C++` is `"C++"`, `/users/a&admin=true` one value.

* `%2F` decodes to `/` **inside** its segment and never splits it:
  `GET /users/a%2Fb` binds `"a/b"` on `/users/{id}` and never reaches
  `/users/a/b`.
* A path that does not decode — `%zz`, a trailing `%2`, non-UTF-8 like
  `%FF` — answers **`400` before routing**, through the global middleware
  and `map_err` / problem details, as a `404` does.
* The raw path stays in the request's `Uri`.
* **Never decode a parameter again.** `%2E%2E` already arrived as `..`; a
  second decode double-decodes `100%25` into an error and lets `%252F`
  pass a `/` check as `%2F`. Check the value the handler receives.
* **Write literal segments as their text**: `"/lit/a b"`, `"/café"`. A
  literal (or a group or static-mount prefix) carrying a percent-escape —
  `"/lit/a%20b"` — **panics** at mapping, since it could only match
  `a%2520b`.

Before 0.13.0 positional extractors read values undecoded and accepted
malformed escapes; code that decoded `String` parameters by hand must drop
it on upgrade.

## Query parameters

```rust
use volga::{Query, ok};
use serde::Deserialize;

#[derive(Deserialize)]
struct Pagination {
    page: u32,
    per_page: u32,
    sort: Option<String>,   // absent -> None instead of 400
}

app.map_get("/items", |Query(p): Query<Pagination>| async move {
    ok!("page {} of {}", p.page, p.per_page)
});
```

`T` is any `Deserialize` type, including `HashMap<String, String>`. A
missing non-`Option` field is a `400` with the serde message; wrap fields in
`Option<T>` to make them optional.

## Bodies

| Extractor | Reads | Feature |
|---|---|---|
| `Json<T>` | `application/json` into a `Deserialize` type | — |
| `Form<T>` | `application/x-www-form-urlencoded` | — |
| `Multipart` | `multipart/*` (any subtype) | `multipart` |
| `File` | a single streamed upload | — |
| `ByteStream` | the body as an async byte stream | — |
| `HttpBody` | the raw body (0.9.4+) | — |
| `HttpBodyStream` | the body as a `Stream<Item = Result<Bytes, Error>>` | — |
| `HttpRequest` | the whole request | — |

Only **one** body extractor per handler: the body is a stream that is consumed
once. Head-only extractors (`Path`, `Query`, `HttpHeaders`, `Dc`) combine with
it freely. The default body limit is 5 MB; a body over it answers **`413`**
however it is read (see [Body size limits](#body-size-limits)).

```rust
use serde::Deserialize;
use volga::{Json, ok};

#[derive(Deserialize)]
struct User { name: String }

app.map_post("/users", |user: Json<User>| async move {
    ok!("Hello {}!", user.name)   // Json<T> derefs to T
});
```

`Json<T>`, `Form<T>`, `Query<T>` and `Path<T>` are tuple structs — `.0`
unwraps, and `Deref` gives field access without it.

Since 0.9.9, any of them can be wrapped in `Valid<..>` (`ValidJson<T>`,
`ValidQuery<T>`, `ValidForm<T>`, `ValidPath<T>`) to run the payload's own
`Validate` impl before the handler is entered — see
`references/validation.md`.

### The raw body

<!-- snippet: skip -->
```rust
use http_body_util::BodyExt;              // volga does not re-export it
use volga::{HttpBody, http::HttpBodyStream, ok};

// collected
app.map_post("/raw", |body: HttpBody| async move {
    let bytes = body.collect().await?.to_bytes();
    ok!(format!("received {} bytes", bytes.len()))
});

// streamed — nothing is held in memory at once
app.map_post("/count", |mut stream: HttpBodyStream| async move {
    let mut total = 0;
    while let Some(chunk) = stream.next().await {   // futures_util::StreamExt
        total += chunk?.len();
    }
    ok!(format!("received {total} bytes"))
});
```

`HttpBody` is returnable too, which makes a pass-through handler a move rather
than a copy. Its constructors — `full`, `empty`, `json`, `form`, `file`,
`stream`, `stream_bytes` — are what the response macros expand to.

### Files

```rust
use volga::{App, File};

app.map_post("/upload", |file: File| async move {
    file.save_as("uploads/received.bin").await   // or .save("uploads") to keep the sent name
});
```

### Multipart (feature `multipart`)

Incoming:

```rust
use volga::{Multipart, ok};
use std::path::Path as FsPath;

app.map_post("/upload", |files: Multipart| async move {
    files.save_all("uploads").await
});

// or per field — `next_field` takes `&mut self`, so bind it `mut`
app.map_post("/upload", |mut files: Multipart| async move {
    let dir = FsPath::new("uploads");
    while let Some(field) = files.next_field().await? {
        field.save(dir).await?;
    }
    ok!("uploaded")
});
```

Outgoing — `Multipart` also implements `IntoResponse`:

```rust
use bytes::Bytes;
use volga::{Multipart, multipart::{MultipartSubtype, Part}};

app.map_get("/report", || async {
    Multipart::from_parts([
        Part::text("greeting", "hello"),
        Part::file("logo", "logo.png", Bytes::from_static(b"\x89PNG")),
    ])
    .with_subtype(MultipartSubtype::Mixed)
});
```

`Part::text` / `bytes` / `file` / `stream` / `new` build parts; the
`try_*` counterparts return an error instead of panicking and are the right
choice when a name or filename comes from untrusted input.
`Multipart::from_stream` emits parts lazily; `Multipart::into_outgoing()`
re-encodes an incoming multipart for proxying (boundary is regenerated, so
it is not byte-perfect — forward the raw `HttpBody` when that matters).


### Body size limits

The limit is set at three levels, and the **most specific one wins**: a
route's over its group's, a nested group's over the outer group's, a
group's over the application's. Group and route limits are 0.13.1+; they
replace the application's, so they can raise it as well as lower it.

```rust
use volga::{App, Json, Limit, http::HttpBodyStream, ok};

let mut app = App::new().with_body_limit(Limit::Limited(1024 * 1024)); // app: 1 MB

app.group("/api", |api| {
    api.with_body_limit(Limit::Limited(64 * 1024));          // the group: 64 KB

    api.map_post("/messages", |Json(text): Json<String>| async move { ok!(text) });

    api.map_post("/attachments", |_stream: HttpBodyStream| async move {
        // stream it somewhere
        ok!()
    })
    .with_body_limit(Limit::Limited(20 * 1024 * 1024));    // one route: 20 MB
});

app.map_post("/proxy", |body: volga::HttpBody| async move {
    volga::HttpResponse::builder().status(200).body(body)
})
.without_body_limit();                                      // counts bytes elsewhere
```

* `App::with_body_limit` / `without_body_limit` consume `self`;
  `RouteGroup::with_body_limit` / `without_body_limit` take `&mut self`
  inside the closure; `Route::with_body_limit` / `without_body_limit`
  chain after `map_*`. No feature needed. `[server] body_limit_bytes` in a
  config file sets the application's.
* A group's limit reaches every route it registered, nested groups'
  included, **whatever the order** in the closure, and its `map_fallback`.
  A route or nested group with its own keeps it. A request no route or
  group claims gets the application's.
* `Limit::Default` is the **framework default (5 MB)**, not the enclosing
  limit — to inherit, set nothing. `Limit::Unlimited` = `without_body_limit()`.
* `HttpRequest::body_limit() -> Option<usize>` is the limit the request got.
* Over the limit → **`413 Content Too Large`** through `Json`, `Form`,
  `File`, `Multipart`, `HttpBody`, streams, and decompression limits too.
  A `Content-Length` over the limit fails the **first** read, before any
  byte (an `Expect: 100-continue` client gets `413` and never uploads); a
  chunked body fails once it has sent more than fits. A refused body
  yields one error, then ends. A handler that never reads the body is not
  affected.
* Only lift the limit on a route that counts the bytes itself — never on
  one that collects the body into memory.

## Headers

```rust
use volga::headers::{Header, ContentType, HttpHeaders, headers};

// a well-known header
app.map_get("/a", |ct: Header<ContentType>| async move { ok!("{ct}") });

// custom headers, declared once
headers! {
    (ApiKey, "x-api-key"),
    (CorrelationId, "x-corr-id")
}
app.map_get("/b", |key: Header<ApiKey>, id: Header<CorrelationId>| async move {
    ok!("{key}; {id}")
});

// the whole map
app.map_get("/c", |headers: HttpHeaders| async move {
    let key = headers.get_raw("x-api-key");
    let typed: Header<ApiKey> = headers.try_get()?;
    ok!("{typed}")
});
```

With the `macros` feature (**not** in `full`) the attribute form is
available too:

```rust
use volga::headers::http_header;

#[http_header("x-api-key")]
struct ApiKey;
```

A `Header<T>` parameter is required: a request without the header answers
`400`. Take `HttpHeaders` and `get_raw` when the header is optional.

Writing headers on a response uses the semicolon form — see
`responses.md`.

## Cookies (feature `cookie`)

```rust
use volga::{HttpResult, http::Cookies, ok, status, see_other};

async fn login(cookies: Cookies) -> Result<(HttpResult, Cookies), volga::error::Error> {
    Ok((see_other!("/me"), cookies.add(("session-id", "generated"))))
}

async fn me(cookies: Cookies) -> HttpResult {
    match cookies.get("session-id") {
        Some(c) => ok!("hello {}", c.value()),
        None => status!(401, "Unauthorized"),
    }
}
```

Returning the `Cookies` alongside the response is what emits `Set-Cookie`.
Build cookies with attributes through the `cookie` crate's builder:

<!-- snippet: skip -->
```rust
use cookie::{Cookie, time::Duration};

let c = Cookie::build(("session-id", value))
    .path("/")
    .secure(true)
    .http_only(true)
    .max_age(Duration::days(1))
    .build();
```

`SignedCookies` (feature `signed-cookie`) and `PrivateCookies`
(`private-cookie`) work identically but need a key registered in DI —
`app.add_singleton(SignedKey::generate())` or `PrivateKey::generate()`.
Both features imply `di`.

## Other extractors

| Extractor | Gives |
|---|---|
| `Dc<T>` | a dependency from the container (feature `di`) |
| `Config<T>` | a bound configuration section (feature `config`) |
| `CancellationToken` | cancelled when the client disconnects |
| `ClientIp` | the peer address (`into_inner()` for the `SocketAddr`) |
| `HostEnv` | content root, index and fallback file settings |
| `Basic` | parsed `Authorization: Basic` credentials (feature `basic-auth`) |
| `BearerTokenService` | encode/decode JWTs (feature `jwt-auth`) |
| `HttpRequestMut` | a mutable request, only inside `tap_req` |
