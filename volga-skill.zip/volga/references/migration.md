# Upgrading and troubleshooting

Symptom-first. If code that "used to work" stopped compiling, or a request
is rejected for no obvious reason, look here before rewriting anything.

## Compile errors

| Error | Cause | Fix |
|---|---|---|
| `` use of deprecated method `..::cache_control`: renamed to `with_cache_control` ``, `` `..::use_problem_details`: renamed to `map_problem` `` or `` type alias `..::ValidPath`: renamed to `ValidNamedPath` `` — a warning, an error under `-D warnings` | 0.14.1 renamed them; the old names forward to the new ones | `with_cache_control`, `map_problem()`, `ValidNamedPath<T>` — same behavior |
| `no method named with_cache_control` on a `Route` / `RouteGroup`, `map_problem` on `App`, or `set_bearer_auth` / `set_oauth` / `set_cache_control` / `set_http2_limits` / `set_decompression_limits`; `cannot find type ValidNamedPath` | before 0.14.1 | upgrade to 0.14.1, or use `cache_control`, `use_problem_details()`, `ValidPath<T>`, `with_X(\|_\| config)` |
| `cannot assign to data in dereference of Dc<T>` (E0594), or `cannot borrow data in dereference of Dc<T> as mutable` (E0596) | 0.14.0: `Dc<T>` has no `DerefMut` — a write through it changed a private copy | interior mutability inside `T` (`Mutex` / `RwLock` / atomic), changed through `&self`; `Dc::cloned()` for a private copy |
| `argument never used` on an `ok!` / `status!` call | headers passed after a comma | use `;` before the header array |
| `` `Path<X>` is not an extractor `` with a note that `Path<T>` reads by position | `X` is a struct; `Path<T>` takes a tuple or one `FromPathArg` type | `NamedPath<X>` with `Deserialize`, or a tuple |
| `` `X` is not an extractor `` with `` the trait `FromPathArg` is not implemented for `X` `` | 0.13.0: a type of your own is a path parameter only through `FromPathArg` (implementing `FromStr` is not enough) | `impl FromPathArg for X { fn from_path_arg(arg: &PathArg) -> Result<Self, Error> { arg.parse().map(X) } }`, or wrap it in `Json` / `Query` / `NamedPath` |
| panic: `invalid route ...: the segment ... carries a percent-escape` | 0.13.0: literal segments, group prefixes and static-mount prefixes are matched against the decoded path | write the text it spells: `"/docs v1"`, not `"/docs%20v1"` |
| `` `X` cannot be the error of a request handler's `Result` `` | 0.12.0: a handler's `Err` must be `Error` or implement `IntoError`; `X` is a response type (`HttpResponse`, `Json<T>`), an integer, or an error type with only `From<X> for Error` | return the response as `Ok`, attach a body with `Error::with_response`, use `StatusCode`, or turn the `From` impl into `impl IntoError` |
| `conflicting implementations of trait From<X> for volga::error::Error` (E0119) | 0.12.0: `IntoError` provides that `From` through a blanket impl | delete the `From` impl; keep `IntoError` |
| `` `F` is not a filter `` on a filter returning `Result<(), E>` | 0.12.0: a filter's `E` must be `Error` or implement `IntoError`, not just `std::error::Error` | `.map_err(\|e\| (StatusCode::BAD_REQUEST, e))`, or wrap it in an `IntoError` type |
| `FilterResult::with_error` rejects its argument | 0.12.0: it takes what a filter's `Err` takes | as above |
| `method takes N generic arguments but N-1 generic arguments were supplied` on `map_*` / `filter` / `map_ok` / ... | 0.11.0 added the handler-shape marker as the last generic parameter | add a trailing `_`: `map_get::<_, _, (i32,), _>(..)` |
| "is not a request handler" on a synchronous closure | the closure returns something that is not `IntoResponse`; with neither shape matching, rustc cannot say which was meant | fix the return type |
| `blocking` rejects a handler | it takes a synchronous handler only | drop `async`, or drop `blocking` |
| `a catch-all parameter reads the rest of the path` panic | a segment after `{*name}`, possibly from a group prefix ending in one | make the catch-all the last segment |
| `no method named map_get found for struct App` | `App` bound without `mut`, or a `with_*` called after routing | `let mut app = App::new()...;` then routes |
| `cannot find derive macro Claims` | `jwt-derive` is not enabled (`full` does not include it) | add `jwt-auth-full` or `auth-full` |
| `cannot find function permission in volga::auth` | it was not re-exported before 0.9.9 | upgrade, or use `volga::auth::authorizer::permission` — **not** `permissions`, which the compiler suggests and which is a different function |
| `cannot find derive macro Validate` | `validation-derive` is not enabled | add it (it *is* in `full`) |
| `cannot find attribute http_header` | `macros` is not enabled | add `macros` |
| `` `#[http_header]` can only be applied to a unit-like struct `` | 0.10.1 enforces it; a field was ignored before | drop the fields — the value lives in `Header<T>` |
| `` `Claims` can only be derived for structs `` | 0.10.1 enforces it; an enum expanded to an empty impl before | derive it on the struct the payload deserializes into |
| `no method named map_static_assets found for struct App` | renamed in 0.10.0 | `use_static_assets()` — there is no route to map any more |
| `no method named without_implicit_head found for struct App` | removed in 0.10.0 | delete the call; a `GET` route answers `HEAD` itself, and mapping `map_head` overrides it |
| `cannot find trait FromRawRequest` | removed in 0.10.0 | `map_fallback` takes `FromRequestParts`, which is the same set |
| a hand-written `impl FallbackHandler` no longer compiles | `call` takes `HttpRequest` instead of `Request<Incoming>` in 0.10.0 | change the argument type |
| `cannot find function with_default_cors` | removed in 0.9.1 | `.set_cors(CorsConfig::default())` |
| `cannot find function with_default_tracing` | removed in 0.9.1 | `.set_tracing(TracingConfig::default())` |
| `cannot find macro problem` | removed in 0.9.2 | `volga::error::Problem::new(..)` |
| `with_hsts_preload` / `with_hsts_max_age` not found | removed in 0.9.1 | `.with_hsts(\|h\| h.with_preload())` |
| `this function takes 0 arguments but 1 was supplied` on `with_credentials` / `with_preload` / `with_sub_domains` / `with_vary_header` / `with_accept_unmasked_frames` | they stopped taking `bool` in 0.9.1 | drop the argument, or call the `without_*` twin |
| `field status of struct Error is private` | fields became methods in 0.9.0 | `error.status()`, `error.instance()` |
| `no function from_rsa_der` / `ErrorKind` not found | `jsonwebtoken` left the public API in 0.9.1 | use `from_secret` / `from_base64_secret` / `from_rsa_pem` / `from_ec_pem` / `from_ed_pem` / `from_env` / `from_file` |
| `no function from_jwk` on `DecodingKey` | before 0.13.2 | upgrade to 0.13.2, or convert the key to PEM. It takes JSON text (`&str`), not a `jsonwebtoken::jwk::Jwk` |
| `no method named with_jwks_uri` on `OAuthConfig` | before 0.13.2 | upgrade to 0.13.2 |
| cannot construct `Problem` / `TlsConfig` / `RedirectionConfig` with a struct literal | `#[non_exhaustive]` since 0.9.2 | use the builders |
| non-exhaustive match on `Authorizer`, `Encoding`, `WsEvent`, `OAuthErrorCode` | `#[non_exhaustive]` | add a `_ =>` arm |
| `future cannot be sent between threads safely` | a `std::sync` guard held across `.await` | drop the guard first, or use `tokio::sync` |
| a `TokenSet { .. }` literal misses a field | `dpop_jkt` added in 0.9.8 | add `dpop_jkt: None` for a bearer token |
| `MiddlewareHandler` / `TapReqHandler` / `MapOkHandler` / `MapErrHandler` not found | renamed in 0.8.9 | `With`, `TapReq`, `MapOk`, `MapErr`; the methods are `with`, `tap_req`, `map_ok`, `map_err` |

## Runtime symptoms

| Symptom | Cause |
|---|---|
| `run()` returns `Err` with `` `T` is not registered, and is resolved by `GET /..` `` | 0.14.0: what handlers and middleware take is checked at startup; the route answered `500` before. Register `T`, or take `Option<Dc<T>>` where it is optional. Signed / private cookies need their key |
| panic at mapping: `` `GET /x`: the handler reads N path parameters, but the route declares M `` | 0.14.0: such a route answered `500` on every request. Declare the parameters (in the route or the group prefix), read them with `Query<T>`, or take `Option<T>` |
| panic at mapping: `` the handler reads 1 path parameter through `Path<T>`, but the route declares 2 `` | 0.14.0: `Path<T>` of a single type on a route with several. A tuple, or `NamedPath<T>` |
| a handler taking `HttpRequest` sees path parameters, or `map_msg("/ws/{room}", \|msg: String, room: String\| ..)` starts working | 0.14.0: they used to be taken out of the request even when nothing read them. Expected |
| a filter's `false` answers `Request rejected by filter` | 0.14.0: was `Validation: One or more request parameters are incorrect`. Match on the `400`, not the text |
| a body over the limit answers `request body is larger than the limit` | 0.14.0: was `length limit exceeded`, behind `JSON parsing error:` / `Form Data parsing error:` / `File Stream error:`, or `Multipart error: failed to read stream`. Match on the `413` |
| panic at mapping: `` CORS policy "x" is not configured `` | `cors_with("x")` without a policy named `x` in `with_cors`. It said `cors policy` before 0.14.0 |
| every request to a protected route answers `400`, but works locally | `require_https` defaults to on; a proxy terminates TLS. `require_https(false)` |
| a handler cannot read `Authorization` after auth succeeded | `strip_token_from_request` defaults to on |
| valid-looking tokens rejected as missing a claim | `with_aud` made `aud` required. `without_strict_aud()` |
| `401` with a bare `Bearer` challenge | no credentials at all (RFC 6750 §3) |
| `400` with `invalid_request` | the `Authorization` header is present but malformed |
| `401` with `invalid_token` | the token was parsed and rejected — expired, bad signature, wrong claim, or malformed. **`403` before 0.10.1** |
| `403` with `insufficient_scope` | the token is valid but lacks the role or permission the route asks for |
| `503` from a protected route | validation could not complete: issuer-based validation with no JWKS ever loaded, or an unreadable verification key. With `with_jwks_uri`: that URL is unreachable, or `http://` while `require_https` is on |
| `OAuth issuer discovery failed` in a container / cluster while the issuer is up | the server cannot reach the URL tokens carry in `iss`. Since 0.13.2 keep `with_issuer` and add `with_jwks_uri(<reachable URL>)` |
| every token `401 invalid_token` after `with_issuer` was pointed at an internal URL | tokens carry the public `iss`. Restore it and fetch keys with `with_jwks_uri` (0.13.2+) |
| startup fails on `unknown field jwks_uri` in `[oauth.client]` | the file targets 0.13.2; the crate is older. Upgrade |
| `run()` returns `Err` with `Bearer auth: the decoding key is ..., which cannot verify ... tokens` | 0.13.3: a static key must fit every algorithm `with_alg` names (the encoding key the first). Name the key's family — an RSA / EC / Ed25519 key with no `with_alg` is left with `HS256` |
| `HS256` tokens `401` after upgrading, with `with_alg(Algorithm::HS512)` set | 0.13.3: the first `with_alg` replaces `HS256`. Name both, the one to issue first |
| tokens without `iss` `401 invalid_token` after upgrading | 0.13.3: `with_iss` makes `iss` required. Have the issuer add it, or drop `with_iss` |
| another service rejects tokens this app issues after upgrading | 0.13.3: `encode` signs with the first `with_alg`, no longer always `HS256`. Put the algorithm the verifier expects first |
| panic at startup: CORS | `use_cors()` without `with_cors(..)`, or credentials combined with a wildcard |
| panic at startup: HSTS | `with_preload()` with `max_age` under one year |
| panic at startup: config | `with_default_config()` and no `app_config.toml` / `.json`, or a required `bind_section` missing |
| panic: `with_max_header_list_size(Limit::Unlimited)` | treated as misconfiguration since 0.9.0 |
| no CORS headers anywhere, no error | only a **named** policy is configured; routes need `cors_with("name")` |
| rate limiting registered but never triggers | `with_*` without the matching `use_*` or per-route call |
| token validation ignores the issuer | `with_oauth(..)` without `app.use_oauth()` |
| OpenAPI configured but nothing served | no `app.use_open_api()` (it logs a warning) |
| `406` on a response | `Accept-Encoding` asked for an algorithm whose feature is off |
| `415` on a request | `Content-Encoding` names an algorithm whose feature is off |
| the server listens on every interface | that is `App::new()`'s default off Windows. `bind` explicitly |
| the process hangs or panics on start | `run_blocking()` called inside a Tokio runtime |
| everything under `/api` answers `400` after adding a filter | a `filter` returning `false` refuses with `400` (`Request rejected by filter` since 0.14.0); return `Err((StatusCode::.., ".."))` for another status |
| a route that answered `200` now answers `401` / `403` / `429` | 0.10.0: its group's `authorize` / `token_bucket` was registered *after* it and used to be skipped; a group is now a scope |
| a `HEAD` health check that answered `200` now answers `401` / `403` | 0.10.0: `HEAD` travels through the `GET` route's middleware instead of a second bare route |
| an unknown path answers `401` instead of `404` | 0.10.0: global short-circuiting middleware (`filter`, `authorize`, an early-returning `with`) now runs for unmatched requests |
| clients hit the rate limit sooner than before | 0.10.0: a global limiter counts requests that match no route |
| a route stopped answering after `use_static_files()` was added | 0.10.0: a file on disk answers before a route for the same path. Mount under a group prefix |
| static files stopped being compressed, or lost their CORS headers | 0.10.0: the mount sits where it was registered. Call it after `use_compression()` / `use_cors()` |
| `app.group("/{tenant}", \|g\| g.use_static_files())` serves nothing | 0.10.0: a mount matches a literal prefix; the accidental parameter-folding it relied on is gone. It warns at startup |
| `NamedPath<T>` fails to deserialize, or reads `None` for a name in the pattern | 0.10.0: each endpoint binds the names its own pattern was written with, not the first route's through that position |
| panic at registration: `ambiguous route` | one verb naming its own route twice under two parameter names, or a `GET` and a `HEAD` disagreeing. Name them identically or part on a literal segment |
| `GET /` serves a stale `index.html` after a deploy | pre-0.9.11: the shell was served `immutable`. Upgrade, or `with_shell_cache_control(..)` |
| `run()` returns `Err` naming a service, and the server never starts | 0.10.1: the DI graph is validated first. Register what is missing, or break the cycle it names |
| panic: `dependency cycle: A -> B -> A` | 0.10.1 reports at resolution what used to deadlock (scoped) or abort the process (transient) |
| a test's first request is refused | pre-0.10.1 `TestServer` returned before its port was bound |
| a route that answered `404` for a path with a literal prefix now answers | 0.10.1: the lookup backtracks to a parameter when the literal leads nowhere. This is the fix, not a regression |
| every client revalidates `index.html` once after upgrading | 0.10.1: the shell's `ETag` is derived from its bytes. Expected, and one round trip |
| `exclude_hosts` started excluding a host it did not before | 0.10.1: entries match by host name on any port, and config-file entries are normalized |
| an HTTP/2 client finally gets an HTTPS redirect | 0.10.1: the redirect listener serves HTTP/1.1 and HTTP/2, and reads the host from the request target |
| a browser WebSocket client's `JSON.parse(event.data)` starts working, or a client reading replies as binary gets text | 0.11.0: `Json<T>` is sent as a text frame |
| a `NamedPath<T>` value keeps a `&` or `+` it used to split on or turn into a space | 0.11.0: a path is not form-decoded; only percent-escapes are |
| an SSE feed or stream is cut off during shutdown | the shutdown timeout closed it. End it on the `ShutdownHandle` extractor's `cancelled()`, or raise `with_shutdown_timeout` |
| a request's `CancellationToken` fires during shutdown | 0.11.0: the shutdown timeout closed its connection |
| other requests stall while one runs | a synchronous handler blocks the runtime worker. Wrap it in `blocking` |
| a non-`GET` request to an unknown path answers `405` with `Allow: GET,HEAD` instead of the SPA shell | 0.11.1: the fallback file answers `GET` and `HEAD` only |
| `map_fallback` is never reached in an app with `use_static_files()` | 0.11.1: under a root mount the shell covers every `GET` path. Mount under a prefix, or give the API group its own `map_fallback` |
| a group's fallback file stopped answering outside the group's prefix | 0.11.1: `RouteGroup::use_static_files` serves the shell under its own prefix, as it serves the files |
| a group's middleware runs once for a route the group mapped under two spellings of its parameters | 0.11.1: a group records each route once, by the position the router reads |
| a handler returning `Err(String)` / `Err("..")` answers `500` instead of `200` | 0.12.0: a handler's `Err` goes to the error handler, and a message has no status. Return `Err((StatusCode::BAD_REQUEST, ".."))` |
| `Err(StatusCode::..)` now has a body (its reason phrase), or Problem Details | 0.12.0: it goes through the error handler |
| `map_err` / `use_problem_details()` now sees errors it never saw — `Err(StatusCode)`, `Err(Problem)` | 0.12.0: every handler `Err` reaches it |
| a filter that answered `400` now answers `401`, `403`, `404`, `422`… | 0.12.0: a filter's `Err` keeps its status — `OAuthError` by code, `io::Error` by kind, `ValidationError`, `StatusCode` |
| a path parameter is decoded twice — `100%25` fails, `%2520` reads as a space | 0.13.0: the router decodes every parameter already. Remove the handler's own decoding |
| a request that reached a handler now answers `400` before routing | 0.13.0: its path carries a malformed escape (`%zz`, trailing `%2`) or non-UTF-8 (`%FF`); `String` / `Path<T>` used to accept it. It goes through `map_err` |
| `GET /users/a%2Fb` binds `"a/b"` where it used to bind `"a%2Fb"` | 0.13.0: positional extractors read the decoded value; `%2F` still never splits a segment |
| a literal route with a space or non-ASCII (`/café`) starts answering | 0.13.0: literals are matched against the decoded path. Expected |
| `500` with `` `Path<T>` of a single type reads one path parameter `` | `Path<u32>` on a route declaring two or none — in middleware, or in a handler before 0.14.0 (a panic at mapping since). Use a tuple or `NamedPath<T>` |
| `500` with `the handler reads more path parameters than the route declares` | more positional arguments than the pattern has `{..}` segments — before 0.14.0; since, mapping it panics. Fix the pattern or the signature |
| a static file under `/st%61tic/..` or `//static/..` is now served | 0.13.0: a mount matches its prefix against decoded segments, as the router does |
| a body over the limit answers `413` where tests expected `400` | 0.13.1: `413 Content Too Large`, through `Json` / `Form` / `File` / `Multipart` / raw reads and decompression limits alike, same message. Update the assertion |
| a handler that read only the start of a large upload now gets `413` | 0.13.1: a `Content-Length` over the limit fails the first read, before any byte. Raise the limit on that route with `.with_body_limit(..)` |
| an `Expect: 100-continue` client never sends the body and gets `413` | 0.13.1: refused on its `Content-Length` before `100 Continue`. Expected |
| one route needs a bigger body than the rest, so the whole app's limit was raised | since 0.13.1 set it on that route (`.with_body_limit(..)`) or its group, and lower the app's back |
| a route keeps a small limit inside a group that raised it | the most specific limit wins — the route set its own. `Limit::Default` on a route means 5 MB, not "inherit" |
| a debug build warns `OpenAPI: ... describes ... as a map` at startup | 0.11.2: a `#[serde(flatten)]` input cannot be inferred. Describe it with `with_request_schema` / `with_query_schema` |
| a debug build warns `OpenAPI: ... is described as ...` at startup, or the spec shows another route's parameter name | 0.11.2: routes naming one position differently share one templated path. Name the parameters alike |

## Version-by-version

### 0.14.1 — one naming rule, `set_*` peers
No API break; the renames keep the old names as deprecated aliases, and
nothing changes at runtime.

* **Renamed**, old name deprecated: `Route::cache_control` and
  `RouteGroup::cache_control` → `with_cache_control`, the name `App` had;
  `App::use_problem_details` → `App::map_problem`, the name `Route` and
  `RouteGroup` had; `ValidPath<T>` → `ValidNamedPath<T>`, since it is
  `Valid<NamedPath<T>>` — there is no alias over `Path<T>`.
* **`set_X(config)` for every `App::with_X(closure)` that builds a
  config**: `set_bearer_auth`, `set_oauth`, `set_cache_control`,
  `set_http2_limits`, `set_decompression_limits`. `set_X` replaces the
  config whole; `with_http2_limits` and `with_decompression_limits` hand
  their closure the limits already set.
* `with_cache_control` takes `FnOnce` on all three levels (a relaxed bound
  on `App`).
* `map_problem()` is `map_err` with volga's own handler: on `App`,
  whichever of the two is called last handles the errors.

### 0.14.0 — `Dc<T>` read-only, services and path parameters checked at startup
**Breaking.** One compile error; two checks stop an app that used to answer
`500` on some routes.

* **`Dc<T>` has no `DerefMut`.** It used `Arc::make_mut`: the container
  holds a handle on every singleton, and on a scoped service until its
  request ends, so a write cloned the instance and no other request saw
  it. A write is E0594 / E0596 now. State goes behind interior mutability
  in `T`; `Dc::cloned()` gives a private copy. `Dc<T>` is `Clone` for
  every `T`.
* **`App::run` returns `Err` for an unregistered `Dc<T>`** taken by a
  handler, `map_ws` / `map_msg`, `map_err`, `map_fallback` (app or group),
  or `with` / `filter` / `map_ok` / `map_err` / `tap_req` (app, group,
  route); signed / private cookies without their key too. Only what can
  still run is checked. `Option<Dc<T>>` opts out, `Result<Dc<T>, Error>`
  does not. Not checked: `wrap`, `attach`, `HttpContext::resolve`, the
  `Container`. An extractor of your own declares through `dependencies` on
  `FromRequestRef` / `FromRequestParts` / `FromContainer`; `volga-di` adds
  `ContainerBuilder::require` and `Issue::Unregistered`.
* **Mapping a handler that reads more path parameters than its route
  declares panics**, naming the route; it answered `500` on every request.
  Counted: positional parameters and `Path<T>` (a tuple of `N` needs at
  least `N`, a single type exactly one). `Option<T>` / `Result<T, Error>`
  opt out; reading fewer is fine. Checked: `map_*` of the app and of a
  group (the prefix counts), `map_ws`, `map_msg`, `map_fallback`, a group's
  fallback. Not checked: `NamedPath<T>`, middleware.
  `FromPathArgs::ARITY` (default: any number) states what a type of your
  own reads.
* A handler taking `HttpRequest` sees its route's path parameters
  (`path_args()`, `extract::<Path<T>>()`), and `map_ws` / `map_msg` hand
  them to their handler.
* Same statuses, new messages: a filter's `false` →
  `Request rejected by filter`; a body over the limit →
  `request body is larger than the limit` through every reader, with no
  parsing prefix — other read failures pass through as they are too;
  `cors_with` with an unknown name panics naming the policy, at the call.

### 0.13.3 — `with_alg` replaces `HS256`, keys checked at startup, `iss` required
No API break. What differs at runtime, all in bearer auth; issuer-based
validation takes its algorithms from the JWKS and is not affected by
`with_alg`:

* **`with_alg`**: the first call replaces the default `HS256`, later calls
  add. `with_alg(RS256).with_alg(PS256)` accepts `RS256` and `PS256`, no
  `HS256`; `with_alg(HS512)` alone no longer accepts `HS256` — name both.
  Without `with_alg` the list is `HS256`, as before.
* **`BearerTokenService::encode`** signs with the first `with_alg`
  algorithm (`HS256` by default), instead of always `HS256`.
* **Startup check**: a decoding key that does not fit every listed
  algorithm, or an encoding key that does not fit the first, makes
  `App::run` return `Err` naming the key and the algorithms. `HS*` — HMAC
  secret, `RS*` / `PS*` — RSA, `ES*` — EC, `EdDSA` — Ed25519.
* **`with_iss`** makes `iss` a required claim: a token without it is `401`.
  No opt-out. An empty set is a no-op.

### 0.13.2 — keys from an explicit `jwks_uri`, `DecodingKey::from_jwk`
No API break; new API is additive. Nothing changes at runtime for code that
does not use it.

* **`OAuthConfig::with_jwks_uri(url)`**, and `jwks_uri` in
  `[oauth.client]`: the key store fetches the JWKS from that URL and skips
  discovery — for a server that cannot reach the URL tokens carry in `iss`
  (container, ingress). `with_issuer` is still required and still the
  `iss`. The key lifecycle is the same as with discovery. The transport
  policy applies, so `http://` needs `require_https(false)`.
* **`DecodingKey::from_jwk(&str)`**: a static verification key from one
  JSON Web Key (RSA, EC, `OKP`, `oct`). The algorithm still comes from
  `BearerAuthConfig::with_alg`; the key does not follow rotations.

### 0.13.1 — body limits per group and per route
No API break; new API is additive. What differs at runtime:

* **`RouteGroup::with_body_limit` / `without_body_limit`** and
  **`Route::with_body_limit` / `without_body_limit`** set the request body
  limit in place of the application's — raising it or lowering it. The most
  specific limit wins (route → nested group → group → app); a group's limit
  reaches every route it registered, whatever the order, and its fallback.
  `Limit::Default` is the framework 5 MB, not the enclosing limit.
  `HttpRequest::body_limit()` reports the limit the request got.
* A body over the limit answers **`413 Content Too Large`** (it was `400`),
  however it is read, with the same message. A body over a decompression
  limit is `413` too.
* A `Content-Length` over the limit fails the **first** read, before any of
  the body is read: a handler reading only the start of such a body gets the
  `413`, and an `Expect: 100-continue` client is refused instead of sent
  `100 Continue`. A handler that never reads the body is not affected; a
  chunked body is still refused once it has sent more than fits.
* A refused body yields one `413` and then ends: reads after it return the
  end of the body.
* Over HTTP/1 a connection that answered with part of the body unread is
  closed after the response, and lingers first — reading and discarding
  for up to 2 s (500 ms once quiet) — so the client gets the response, not
  a reset. Graceful shutdown waits for lingering connections.

### 0.13.0 — decoded paths, path parameters of your own types
**Breaking** at runtime for positional extractors; new API is additive.

* **The router percent-decodes the path once**, segment by segment, and
  every extractor reads the decoded value. `String`, `u32`, `Path<T>` and
  `FromPathArg` types used to read it undecoded (`NamedPath<T>` decoded it
  leniently); now all read `John%20Doe` as `John Doe`, `%31` as `1`. `+`
  stays a plus. `%2F` decodes to `/` inside its segment and never splits
  it; a catch-all tail is decoded whole. The raw path stays in the `Uri`.
* A malformed escape or non-UTF-8 escapes answer **`400` before routing**,
  through the global middleware and `map_err`, as a `404` does.
* A literal segment, group prefix or static-mount prefix written with a
  percent-escape **panics** at mapping; write its text (`/lit/a b`).
  Literals match decoded paths, so `GET /caf%C3%A9` reaches `/café`.
* A static mount matches its prefix against decoded segments and leaves a
  malformed path to the router's `400`.
* **`FromPathArg`, `PathArg`, `PathArgs`** are public in
  `volga::http::endpoints::args`. A `FromPathArg` type is a handler
  argument, a `Path<(..)>` element, or the `T` of `Path<T>`.
  `PathArg::{name, value, parse}`; `parse` goes through `FromStr` and
  answers `400`. `PathArgs::{iter, len, is_empty}` make `FromPathArgs`
  implementable.
* **`uuid` feature** (in `full`): `uuid::Uuid` as a path parameter.
* **`Path<T>` of a single type**: `Path<u32>`. It answers `500` unless the
  route declares exactly one parameter.
* A handler reading more positional parameters than the route declares
  answers `500`; an extra `Option<T>` reads `None`.
* `Valid<Path<T>>` validates a single `FromPathArg + Validate` parameter.
* The compile error for a non-extractor argument names `FromPathArg`; for
  `Path<Struct>` it points to `NamedPath<T>`.

### 0.12.0 — a handler's `Err` is an error
**Breaking**, partly without a compile error.

* **`volga::error::IntoError`** — the `Err` of a handler's `Result<T, E>`
  is converted into an `Error` and handed to the error handler (`map_err`,
  `use_problem_details`, the default). Implemented for volga's error types,
  `StatusCode` (canonical reason), `(StatusCode, E)`, strings and
  `Box<dyn Error + Send + Sync>` (`500`), `Problem<E>` (answers with
  itself); not for integers. It provides `From<T> for Error`, so `?` works
  with it; a type with both impls is E0119. Applies to handlers, `map_err`,
  `map_fallback`, `with` and `map_ok`.
* `Err(String)` answers `500` (was `200`) — compiles unchanged.
  `Err(StatusCode)` / `Err(Problem)` keep their status but now reach
  `map_err`. `Err(HttpResponse)` / `Err(Json<T>)` no longer compile.
* **`Error::with_response` / `has_response` / `take_response`** — an error
  carrying the response it answers with; the default handler and
  `use_problem_details` send it unchanged, with the error's status.
* **`IntoError::describe_openapi`** (feature `openapi`); `Result<T, E>`
  describes both `T` and `E`.
* **A filter's `Err`** goes through `IntoError` too: `OAuthError`,
  `ValidationError`, `io::Error`, `StatusCode`, `(StatusCode, E)`, `Problem`
  and `Error` answer with their own status, instance and attached response;
  strings and boxed errors answer `400`. A type that is only
  `std::error::Error` no longer compiles there. `FilterResult::with_error`
  takes the same types.
* WebSocket conversions (`map_msg`, `on_msg`, `send`, `recv`) accept any
  error convertible into `Error`; a `map_msg` handler can reply with a
  `Message`.
* `Error` shrank from 48 to 32 bytes on 64-bit targets.

### 0.11.2 — hand-written OpenAPI inputs
No API break.

* `volga::openapi::OpenApiSchema` is exported, so `with_request_schema` /
  `with_response_schema` are callable; `with_query_schema` describes query
  parameters from an object schema; `undescribed_inputs()` lists inputs
  described without their fields.
* A `#[serde(flatten)]` input is reported at startup (debug) instead of
  silently published without fields.
* Routes naming one position differently (`GET /users/{id}`,
  `POST /users/{name}`; also a catch-all beside a parameter under another
  verb) are described under one templated path, others renamed by position
  and reported at startup (debug).

### 0.11.1 — group fallbacks, the shell as a route
No API break; nothing to change in code. What differs at runtime:

* **`RouteGroup::map_fallback`** answers any method under the group's
  prefix that no route is mapped at, inside the group's middleware and
  CORS policy, binding the parameters the prefix declares. The deepest
  prefix wins, and a route still answers first (`405` for a method it
  lacks). Not listed, not in OpenAPI, `matched_route()` is `false`.
* **The fallback file is a `GET` route** at the mount's prefix and
  `{*path}` below it, for `GET` and `HEAD` alone — any other method is
  `405` with `Allow: GET,HEAD`. It no longer takes the application's
  fallback slot, so `map_fallback` and `map_fallback_to_file` coexist; a
  root mount leaves `map_fallback` nothing to answer.
* **`RouteGroup::use_static_files`** serves the shell under the group's
  prefix only, with the group's middleware around it.
* A group applies its middleware once to a route mapped under two
  spellings of its parameters.

### 0.11.0 — synchronous handlers, catch-all routes, shutdown timeout
Handler code keeps compiling; only call sites naming generics break.

* **Synchronous handlers and middleware.** A plain `fn` or a closure
  returning its response directly is a handler for every `map_*`, `map`,
  `map_fallback`, `map_err`, `map_conn` and `map_msg`, and middleware for
  `filter`, `map_ok`, `map_err` and `tap_req`. `with` / `wrap` / `attach`
  stay async. `volga::blocking(f)` moves a blocking synchronous body to
  Tokio's blocking pool; it is not cancelled with the request.
* **Breaking, for turbofish only:** handler traits (`GenericHandler`,
  `MapErr`, `Filter`, `MapOk`, `TapReq`, `ws::MessageHandler`) gained a
  marker parameter defaulting to `marker::Async`, and every registering
  method takes it as its last generic. `App::map` / `RouteGroup::map`
  renamed their method parameter `M` → `V`, `map_msg` / `MessageHandler`
  their message parameter `M` → `Msg`. `ErrorFunc` / `FallbackFunc` gained
  it as a defaulted last parameter.
* **Catch-all parameters**, `{*name}`, as the last segment. Lowest
  precedence at every position; at least one segment; not normalized.
* **`App::with_shutdown_timeout(Duration)`** and `[server]
  shutdown_timeout_secs`; the default stays 10 s. Connections still open at
  the timeout are **closed** now (their `CancellationToken` cancelled), and
  `run()` returns once they are gone, redirect listener included.
* **`ShutdownHandle` is an extractor**, always available; `cancelled()` is
  a `'static` future.
* `NamedPath<T>` keeps `&` and `+` as written; `Json<T>` goes out over a
  WebSocket as a text frame; re-mapping a route under another spelling of
  its pattern drops the replaced registration's OpenAPI configuration.
* `rustls` 0.23.45 in the lockfile (RUSTSEC-2026-0285); applications pick
  it up with `cargo update -p rustls`.

### 0.10.1 — statuses, startup checks and shutdown
No API break, nothing to opt into, and nothing fails to compile except two
macros that used to accept what they then ignored.

* **A rejected bearer token is `401`, not `403`** (RFC 6750 §3.1
  `invalid_token`), a token that does not decode included — it used to be
  `400`. `403` with `insufficient_scope` is now only a valid token without
  the required role or permission, and a validation that could not complete
  (unreadable key, unreachable issuer) is `503`. Update tests, refresh
  triggers and alerts that expect `403`.
* **`App::run` validates the DI graph** before starting anything and returns
  `Err` on a cycle or a missing registration, naming every problem at once.
  `ContainerBuilder::validate` is the same check by hand;
  `Inject::dependencies` is a new provided method a hand-written `Inject`
  overrides to declare what it resolves. A cycle reached at resolution now
  panics naming `A -> B -> A` instead of deadlocking (scoped) or aborting the
  process (transient).
* **Graceful shutdown actually waits.** It was skipped for every open
  connection when a request was in flight as the accept loop stopped, so
  `run()` returned mid-response. It now waits up to 10 s, then releases the
  app's services.
* **Route lookup backtracks.** `GET /a/{b}` stopped answering `/a/b` once
  `/a/b/c` was mapped; the lookup now returns to the nearest parameter it
  passed over. Literals still win where they lead to a route, and a literal
  with a handler for another method still answers `405`.
* **HTTPS redirection and HSTS read the host properly.** The redirect
  listener serves HTTP/1.1 as well as HTTP/2 (it accepted only HTTP/2 with the
  `http2` feature on), the host comes from the request target before `Host`
  so HTTP/2 works, a request without a usable host is `400` rather than `404`,
  and HSTS `exclude_hosts` match by host name on any port — normalized
  whether they were written in code or read from a config file.
* **The shell's `ETag` comes from its bytes.** New `ETagSource`
  (`Metadata` / `Content`) with `HostEnv::with_asset_etag` /
  `with_shell_etag` and getters; assets stay on `Metadata`, the index and
  fallback files move to `Content`, so every client revalidates them once
  after the upgrade. It fixes two versions of one file colliding on length
  plus whole-second `mtime` — the ordinary case for a content-hashed build
  deployed with pinned timestamps.
* `#[http_header]` rejects a struct with fields and `#[derive(Claims)]`
  rejects enums and unions; both used to compile and ignore what they were
  given. `FromRequest`, `FromRequestRef`, `IntoResponse` and `GenericHandler`
  carry `#[diagnostic::on_unimplemented]`, so a handler that does not fit is
  told which extractors exist instead of failing on a `pub(crate)` bound.
* `TestServer` returns only once its port is bound. DI and middleware got
  materially faster with nothing to change: scope creation 404 ns → 20 ns,
  a singleton resolve 190 ns → 2 ns under 8 threads, one global middleware
  368 ns → 257 ns. A transient resolved through `Container::resolve` is moved
  rather than cloned, so a side-effecting `Clone` / `Drop` runs once less.

### 0.10.0 — routing, middleware and static files
The largest behavioural release of the line. Nothing here is opt-in.

* **Global middleware runs for requests that match no route.** `wrap`,
  `with`, `filter`, `map_ok`, CORS, compression, tracing and **rate
  limiting** were all skipped for a `404` or a `405` and now are not. A
  global authorizer answers `401` where the router answered `404`; a global
  limiter's budget is spent by traffic that never touched it before.
  `HttpContext::matched_route()` tells a matched request from an unmatched
  one. The per-request scope is built for these requests, so `ClientIp`,
  `CancellationToken`, `Config<T>`, `HostEnv` and `Dc<T>` work in a
  fallback; an error out of a fallback goes to the application's `map_err`.
* **Static files are middleware, not routing.** `map_static_assets` →
  `use_static_assets`; `use_static_files` keeps its name. No startup walk,
  no depth ceiling, nothing in the router — so `use_static_assets()` and
  `map_get("/{id}", ..)` coexist. A file answers before a route for the
  same path. Where the call sits in the pipeline is where the mount sits. A
  group prefix must be literal, and a group's CORS policy does not reach
  the files. `static-files` implies `middleware`.
* **A route group is a scope.** Its middleware, CORS policy and OpenAPI
  config apply to every route it registered, whatever the order inside the
  closure — a route mapped above `g.authorize(..)` used to escape it. The
  `must be called before any map_*` warning is gone with the hazard.
* **`HEAD` goes through the `GET` route.** No second bare route, so route
  and group middleware and CORS now apply. `App::without_implicit_head` is
  removed.
* **Parameter names are per-endpoint.** `POST /users/{name}` beside
  `GET /users/{id}` binds `name`, not `id`. Two spellings that cannot be
  told apart — one verb naming its own route twice, or a `GET` and a `HEAD`
  disagreeing — panic at registration.
* **Re-mapping a route replaces it**, middleware included. `/x`, `/x/` and
  `//x` are one route everywhere.
* `FromRawRequest` removed; `FallbackHandler::call` takes an `HttpRequest`.
* `HttpContext::matched_route`, `App::use_static_assets` and
  `RouteGroup::use_static_assets` are the new API surface.

### 0.9.11
`HostEnv::with_asset_cache_control` / `with_shell_cache_control` and the
matching getters: the static file server's `Cache-Control` is configured
by the role of the file. **The index and the fallback file stopped being
served `immutable`** — `GET /` answered `max-age=86400, public, immutable`
and now answers `no-cache`, so a user who reloaded after a deploy no longer
keeps yesterday's shell for a day. Assets are unchanged.
`CacheControl::ASSET` / `SHELL` / `EMPTY` constants, `CacheControl::asset()`
/ `shell()` header presets, `ResponseCaching::with_cache_control`.
Conditional requests on static files were fixed in five ways, all on the
hot path that change creates. Registering a group-level setting after a
route in that group started warning (0.10.0 removed the hazard instead).

### 0.9.10
Static files nested more than one level deep were served
non-deterministically — the handler folded over `HashMap` iteration order,
so `GET /assets/app.css` reached the filesystem as `assets/app.css` or
`app.css/assets` depending on the request. It hit every Vite/webpack/Parcel
build. A `+` in a request target is now the literal character, and a
malformed `%XX` answers `400`.

### 0.9.9
Input validation: the `Validate` trait, the `Valid<E>` extractor with its
`ValidJson` / `ValidQuery` / `ValidForm` / `ValidPath` aliases,
`ValidationError`, `Invalid<E>` and `#[derive(Validate)]` (feature
`validation-derive`, in `full`). Purely additive — see
`references/validation.md`.

`volga::auth::permission` is re-exported alongside `role`, `roles`,
`permissions` and `predicate`; it was the only one of the five missing, so a
copy of the built-in authorizer list did not compile before this.

Fixed: query parameters vanished from the OpenAPI spec for any handler whose
query struct had a typed optional field (`Option<String>`, `Option<u32>`, ...)
— the operation was published with **no** parameters at all. `f32` / `f64` now
publish `format: "float"` / `"double"` instead of a bare `number`.

### 0.9.8
DPoP sender-constrained tokens in the client (RFC 9449). `TokenSet` gained
`dpop_jkt`. `OAuthErrorCode` gained `UseDpopNonce` and `InvalidDpopProof`,
so code matching them as `Other(..)` no longer matches.
`ClientAuthMethod` is no longer `Copy` — the new `PrivateKeyJwt` variant
carries a key. Client authentication is checked against
`token_endpoint_auth_methods_supported` before a token request is sent.

### 0.9.7
`App::bind` no longer swaps an unparseable address for `0.0.0.0:7878` —
that silent substitution could put a loopback-intended server on every
interface. It now reports an `io::Error`. Host names, unbracketed and
zone-scoped IPv6 are accepted and resolved at startup.

### 0.9.5
The `oauth` and `oauth-client` features: issuer-based bearer validation
(`with_oauth` / `use_oauth`), metadata documents (RFC 8414 / 9728 / OIDC),
and the standalone `volga-oauth-client` crate. Missing credentials on a
guarded route changed from `400` to `401` with a challenge.

### 0.9.4
`map_query` for the HTTP `QUERY` verb, the generic `map(method, path, h)`,
and `HttpBody` as an extractor.

### 0.9.3
`ShutdownHandle`, `App::with_shutdown()`, `with_shutdown_signal(..)`,
`shutdown_on(..)`.

### 0.9.2
`Multipart` became bidirectional (`from_parts`, `from_stream`,
`with_subtype`, `with_boundary`, `into_outgoing`, the `Part` builders).
HSTS `max_age` default moved from 30 days to 1 year, and `with_preload()`
now panics below that. `TlsConfig`, `RedirectionConfig` and `Problem`
became `#[non_exhaustive]`. The `problem!` macro was removed. `Problem`
responses now carry `application/problem+json`.

### 0.9.1 — the big one for auth
* `require_https` **on** by default (non-TLS non-loopback → `400`).
* `strip_token_from_request` **on** by default.
* `with_aud` makes `aud` a required claim; `without_strict_aud()` opts out.
* `BearerTokenService::validation()` removed.
* `volga::auth` stopped re-exporting `jsonwebtoken` types; `EncodingKey`,
  `DecodingKey` and `Algorithm` became volga's own at the same paths.
  `ErrorKind`, `from_jwk` and the `*_der` constructors went away; the
  `from_env` / `from_file` / `from_pem_file` families arrived.
  (`DecodingKey::from_jwk` came back in 0.13.2, as volga's own, taking JSON
  text.)
* `with_credentials`, `with_vary_header`, `with_preload`, `with_sub_domains`,
  `with_accept_unmasked_frames` lost their `bool` argument and gained
  `without_*` twins.
* `App::with_default_cors()` and `App::with_default_tracing()` removed.
* The `TlsConfig::with_hsts_*` shortcuts removed in favour of
  `with_hsts(|h| ...)`.

### 0.9.0
Header mutation methods return `&mut Self`; `append_header` is infallible.
`Error::status` / `Error::instance` became methods.
`with_max_header_list_size(Limit::Unlimited)` panics.

### 0.8.9
`attach()` and the `Filter` trait. The middleware traits were renamed:
`MiddlewareHandler` → `With` (`call` → `with`), `TapReqHandler` → `TapReq`,
`MapOkHandler` → `MapOk`, `MapErrHandler` → `MapErr`, and `type Future` was
removed from each. CORS, JWT auth and rate limiting were reimplemented on
top of `attach`.

## Upgrading 0.9.x → 0.10.x, in order

1. Bump the version and run `cargo check`. Only four things fail to
   compile: `map_static_assets`, `without_implicit_head`, `FromRawRequest`,
   and a hand-written `impl FallbackHandler`.
2. **Then read the behaviour changes, because nothing else will fail to
   compile.** Walk every route group and check what its middleware now
   reaches: a route mapped above the group's `authorize`, `token_bucket` or
   `cors_with` used to escape it and no longer does.
3. Check every `HEAD` consumer — health checks especially. A `HEAD` behind
   an authorized route now answers `401` / `403`.
4. Audit global middleware for what it does to a `404`. A global `filter`
   or `authorize` now decides unmatched requests, and a global rate limiter
   counts them: re-size the budget against real traffic, not against the
   route count.
5. Move the `use_static_files()` / `use_static_assets()` call to where it
   belongs in the pipeline — after `use_compression()` and `use_cors()`.
   Confirm no route shares a path with a file on disk, since the file now
   wins, and that no group serving files has a parameter in its prefix.
6. Grep for `NamedPath` and any by-name parameter read on a route whose
   pattern shares a position with another verb's. The name it receives is
   now its own pattern's.
7. Start the app. Two spellings that used to be silently merged now panic
   at registration, and the message names both patterns and the fix.

## Upgrading 0.10.0 → 0.10.1

Nothing to rewrite. Check three things instead:

1. Grep tests, clients and alerts for `403` against an expired or malformed
   token — that is `401` now, and `400` is no longer a malformed token.
2. Start the app once. If a service was never registered, or two depend on
   each other, `run()` now says so and refuses to start where it used to
   fail a single route at runtime.
3. Expect one revalidation of `index.html` per client after the deploy, and
   nothing else on the wire.

## Upgrading 0.10.x → 0.11.0

1. Bump the version and run `cargo check`. The only thing that can fail is a
   call spelling handler generics out — add a trailing `_` for the marker.
   Bounds written as `F: GenericHandler<Args>` keep their meaning.
2. Grep for `Json` sent over a WebSocket. Clients reading those replies as
   binary must read text; browser clients that `await blob.text()` can go
   straight to `JSON.parse(event.data)`.
3. Grep for `NamedPath` on routes whose values may contain `&` or `+`: they
   now arrive as written.
4. Find endless responses — SSE, proxied streams — and end them on the
   `ShutdownHandle` extractor's `cancelled()`, since the shutdown timeout now
   closes what is still open.
5. Optional: drop `async move { .. }` from handlers and middleware with
   nothing to await, and wrap genuinely blocking bodies in `blocking`.

## Upgrading 0.11.x → 0.12.0

1. Bump the version and run `cargo check`. Work the compile errors: a
   handler `Err` of a response type becomes `Ok(..)` or an error with
   `with_response(..)`; every `impl From<T> for volga::error::Error` becomes
   `impl IntoError for T` (same body, `fn into_error(self) -> Error`); a
   filter's `Err` of a foreign error gets a status with
   `.map_err(|e| (StatusCode::BAD_REQUEST, e))`.
2. **Grep for handlers whose `Err` is a string** — `Result<_, String>`,
   `Result<_, &str>`, `Err(format!(`, `Err("`. They compile and now answer
   `500`. Give each a status: `Err((StatusCode::BAD_REQUEST, msg))`.
3. Review `map_err` and `use_problem_details()`: they now receive every
   handler `Err`, `Err(StatusCode)` and `Err(Problem)` included. A
   `map_err` that rebuilds every error should let an attached response
   through (`if err.has_response() { return Err(err) }`).
4. Grep tests and clients for statuses from filters: an `OAuthError`,
   `ValidationError`, `io::Error` or `StatusCode` returned from a filter now
   answers with its own status instead of `400`.
5. Optional: replace custom error bodies built in handlers with an
   `IntoError` type using `with_response`, and describe it in OpenAPI with
   `describe_openapi`.

## Upgrading 0.12.x → 0.13.0

1. Bump the version and run `cargo check`. Handler code keeps compiling,
   but mapping can now **panic**: run the app (or its tests)
   once and rewrite any literal segment or prefix written with `%XX` as
   its text.
2. **Grep for hand-rolled decoding of path parameters** —
   `percent_decode`, `urlencoding::decode`, `percent_encoding` near a
   `String` path argument, `Path<..>` or a catch-all. Remove it: the value
   arrives decoded, and decoding again breaks `100%25` and re-opens `%252F`.
3. Review checks on path values (file names, slugs, tenant ids): they now
   see `/` and `..` that arrived as `%2F` / `%2E%2E`. Keep checking the
   decoded value — and nothing after it.
4. Update tests and clients that expected a malformed-escape path to reach
   a handler: it answers `400` now, through `map_err`.
5. Optional: replace `String` parameters parsed by hand with a newtype
   implementing `FromPathArg`, `Path<(T,)>` with `Path<T>`, and a
   `NamedPath` wrapper around a single validated field with
   `Valid<Path<T>>`; turn on `uuid` for UUID ids.

## Upgrading 0.13.0 → 0.13.1

1. Bump the version; nothing to change in code.
2. Update tests and clients that expected `400` for an oversized body —
   it is `413` now.
3. Check handlers that read only the start of a body (sniffing a header,
   a magic number): with a `Content-Length` over the limit they get `413`
   on the first read. Give the route the limit it needs.
4. Optional: if the application's limit was raised for a few upload
   routes, lower it back and set the bigger limit on those routes or their
   group with `with_body_limit(..)`; replace an app-wide
   `without_body_limit()` kept for one streaming route with that route's
   `.without_body_limit()`.

## Upgrading 0.13.1 → 0.13.2

1. Bump the version; nothing to change in code.
2. Optional: if a resource server's `with_issuer` was pointed at an
   internal URL (or a proxy rewrote discovery) so a container could reach
   the issuer, put the issuer back to the `iss` tokens carry and add
   `.with_jwks_uri(<internal JWKS URL>)` — or `jwks_uri` in `[oauth.client]`.
3. Optional: a key kept as a JWK and converted to PEM by hand can be loaded
   with `DecodingKey::from_jwk(..)` and `with_alg(..)`; if the issuer
   rotates keys, prefer `with_oauth` instead.

## Upgrading 0.13.2 → 0.13.3

1. Bump the version and run the app once: if `run()` returns
   `Bearer auth: the ... key is ..., which cannot ...`, set `with_alg` to
   the key's family (the error lists the algorithms it takes).
2. Check every `with_alg` list. It is the whole list now — if `HS256`
   tokens must still pass, name `HS256`. The first entry is what `encode`
   signs with; make sure whoever verifies this app's tokens accepts it.
3. If `with_iss` is set, check that every token that must pass carries
   `iss` — tokens without it are `401` now. Drop `with_iss` otherwise.

## Upgrading 0.13.x → 0.14.0

1. Build. A write through `Dc<T>` is E0594 / E0596: move the changing
   state behind a `Mutex` / `RwLock` / atomic inside the service and
   change it through `&self`, or take `Dc::cloned()` where the change was
   only ever meant for this handler.
2. Start the app, or run its tests, once. Mapping a handler that reads
   more path parameters than its route declares panics and names the
   route: declare the parameter, read it with `Query<T>`, or take
   `Option<T>`.
3. If `run()` returns `` `T` is not registered, and is resolved by .. ``,
   register `T`, or take `Option<Dc<T>>` where it is optional. Those
   routes answered `500` before.
4. Anything matching on the text of a `413` or of a filter's `400` matches
   on the status instead.

## Upgrading 0.14.0 → 0.14.1

1. Bump the version. Nothing stops compiling.
2. If `clippy -D warnings` (or `#![deny(deprecated)]`) fails on a
   deprecated name, rename it: `.cache_control(..)` on a route or group →
   `.with_cache_control(..)`, `app.use_problem_details()` →
   `app.map_problem()`, `ValidPath<T>` → `ValidNamedPath<T>`.
3. Optional: a `with_X(|_| config)` written to install a config built
   elsewhere becomes `set_X(config)`.

## Upgrading 0.8.x → 0.9.x, in order

1. Bump the version and run `cargo check`. Work the compile errors with the
   table above — most are mechanical.
2. Audit every `with_*(true)` / `with_*(false)` on CORS, HSTS and
   WebSockets; they are now no-argument on/off pairs.
3. Re-read the bearer auth setup. `require_https` and
   `strip_token_from_request` changed behaviour without changing signatures,
   so nothing will fail to compile — it will fail in staging.
4. Replace `error.status` with `error.status()`.
5. Replace `problem!` with `Problem::new(..)`.
6. Check that nothing constructs `TlsConfig`, `RedirectionConfig` or
   `Problem` by struct literal, and that matches on `Authorizer`,
   `Encoding`, `WsEvent` and `OAuthErrorCode` have a catch-all arm.
7. If `bind` was fed a host name that used to fall back silently, confirm
   the address is what you meant — it is now an error, not a default.
