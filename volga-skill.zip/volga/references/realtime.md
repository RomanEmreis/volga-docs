# WebSockets and Server-Sent Events

## WebSockets (feature `ws`)

With `http2` also enabled, volga serves WebSocket-over-HTTP/2 where possible
and falls back to plain WebSockets on HTTP/1. Nothing in the handler code
changes between the two.

Three levels of control, from least to most:

### `map_msg` — message in, message out

```rust
app.map_msg("/ws", |msg: String| async move {
    format!("Received: {msg}")
});

// synchronous, when there is nothing to await (0.11.0+)
app.map_msg("/ws-sync", |msg: String| format!("echo: {msg}"));
```

`Json<T>` works as the message and as the reply. It is parsed from a text
or a binary frame and **sent as a text frame** — the `map_msg` reply,
`WebSocket::send` and `WsSink::send` alike — so a browser reads a string
from `event.data` and `JSON.parse`s it (0.11.0; it went out as a binary
frame, a `Blob` in the browser, before):

```rust
use volga::Json;
use serde::{Deserialize, Serialize};

#[derive(Deserialize)]
struct In { text: String }

#[derive(Serialize)]
struct Out { echo: String }

app.map_msg("/ws-json", |msg: Json<In>| Json(Out { echo: msg.text.clone() }));
```

Any `TryFrom<Message>` type is a message and any `TryInto<Message>` type a
reply. Since 0.12.0 the conversion error may be any type that converts into
`Error` (`serde_json::Error`, `(StatusCode, E)`, an `IntoError` type), not
only `Error` — for `map_msg`, `on_msg`, `WebSocket::recv`/`send`,
`WsStream::recv` and `WsSink::send`. A `Message` itself is a valid reply:

```rust
use serde::Deserialize;
use volga::ws::Message;

#[derive(Deserialize)]
#[serde(tag = "type", rename_all = "lowercase")]
enum Command { Ping, Echo { text: String } }

impl TryFrom<Message> for Command {
    type Error = serde_json::Error;

    fn try_from(msg: Message) -> Result<Self, Self::Error> {
        serde_json::from_slice(&msg.into_inner().into_data())
    }
}

app.map_msg("/ws-cmd", |cmd: Command| match cmd {
    Command::Ping => "pong".to_string(),
    Command::Echo { text } => text,
});

app.map_msg("/ws-echo", |msg: Message| msg); // keeps text/binary as sent
```

In `map_msg` / `on_msg` a frame that fails to convert is **skipped**
(logged under `tracing`) and the connection stays open; take `Message` or
`Bytes`, or use `recv()`, when the client must hear about it.

### `map_ws` — the socket

```rust
use volga::{App, ws::WebSocket};

app.map_ws("/ws", |mut ws: WebSocket| async move {
    // connection established
    ws.on_msg(|msg: String| async move { format!("Received: {msg}") }).await;
});
```

Split it when send and receive need to run independently:

<!-- snippet: skip -->
```rust
use volga::ws::{WebSocket, WsEvent};

app.map_ws("/ws", |ws: WebSocket| async move {
    let (mut sender, mut receiver) = ws.split();

    tokio::spawn(async move {
        // `Message: TryFrom<&str>` — no `.into()`, which is ambiguous here
        let _ = sender.send("hello from the server").await;
    });

    tokio::spawn(async move {
        while let Some(Ok(event)) = receiver.recv::<String>().await {
            match event {
                WsEvent::Data(msg) => println!("received: {msg}"),
                WsEvent::Close(frame) => println!("closed: {frame:?}"),
            }
        }
    });
});
```

`WsEvent` is `#[non_exhaustive]` — always include a catch-all arm.

### `map_conn` — configure the handshake

```rust
use volga::{HttpResult, ws::{WebSocket, WebSocketConnection}};

app.map_conn("/ws", handle);

async fn handle(conn: WebSocketConnection) -> HttpResult {
    conn.with_protocols(["foo-ws"]).on(handle_socket)
}

async fn handle_socket(mut ws: WebSocket) {
    ws.on_msg(|msg: String| async move { format!("Received: {msg}") }).await;
}
```

`with_accept_unmasked_frames()` and `without_accept_unmasked_frames()` take
no arguments.

### Dependency injection

`Dc<T>` resolves at every layer — the connection handler, the socket
handler and the message handler:

```rust
use volga::{App, HttpResult, di::Dc, ws::{WebSocket, WebSocketConnection}};
use std::sync::{Arc, RwLock};

type Counter = Arc<RwLock<i32>>;

app.add_singleton(Counter::default());
app.map_conn("/ws", handle);

async fn handle(conn: WebSocketConnection, counter: Dc<Counter>) -> HttpResult {
    conn.with_protocols(["foo-ws"]).on(|ws| handle_socket(ws, counter))
}

async fn handle_socket(mut ws: WebSocket, counter: Dc<Counter>) {
    ws.on_msg(move |msg: String| handle_message(msg, counter.clone())).await;
}

async fn handle_message(msg: String, counter: Dc<Counter>) -> String {
    let mut value = counter.write().expect("counter poisoned");
    *value += 1;
    format!("Received: {msg}; message #{value}")
}
```

A `std::sync::RwLock` guard must be dropped before any `.await` in the same
scope, or the future stops being `Send`.

## Server-Sent Events

Built in, no feature flag, works over HTTP/1 and HTTP/2.

```rust
use std::time::Duration;
use volga::{App, http::sse::Message, sse_stream};

app.map_get("/events", || async {
    sse_stream! {
        loop {
            yield Message::new().data("Hello, world!");
            tokio::time::sleep(Duration::from_secs(1)).await;
        }
    }
});
```

`sse_stream!` sets `Content-Type: text/event-stream` and ends the stream
when the client disconnects.

`Message` builds each event:

<!-- snippet: skip -->
```rust
Message::new().data("plain text");
Message::new().json(payload);                // any Serialize (infallible)
Message::new().event("update").id("42").retry(Duration::from_secs(5));
Message::new().comment("keep-alive");
```

For work that should stop when the browser tab closes, combine the stream
with the `CancellationToken` extractor — see `operations.md`.

An endless stream holds its connection open through a graceful shutdown
until the shutdown timeout closes it. End it as the shutdown starts with the
`ShutdownHandle` extractor (0.11.0+):

```rust
use std::time::Duration;
use futures_util::StreamExt;
use volga::{App, ShutdownHandle, http::sse::{Message, SseStream}, sse_stream};

app.map_get("/feed", |shutdown: ShutdownHandle| async move {
    let events = sse_stream! {
        loop {
            yield Message::new().data("tick");
            tokio::time::sleep(Duration::from_secs(1)).await;
        }
    };
    SseStream::new(events.take_until(shutdown.cancelled()))
});
```
